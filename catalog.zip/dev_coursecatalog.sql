-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2016 at 06:54 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dev_coursecatalog`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcategories`
--

CREATE TABLE IF NOT EXISTS `tblcategories` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `courseNumber` int(30) NOT NULL,
  `categoryIndex` varchar(11) CHARACTER SET utf8 NOT NULL,
  `categoryCode` varchar(128) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tblcategories`
--

INSERT INTO `tblcategories` (`index`, `courseNumber`, `categoryIndex`, `categoryCode`) VALUES
(1, 45370, 'Cat1', 'Labor/Employment Law'),
(2, 45388, 'Cat1', 'Antitrust and Fair Competition'),
(4, 45383, 'cat1', 'Finance and Accounting'),
(11, 45305, 'cat0', 'Business Conduct and Ethics'),
(12, 45305, 'cat1', 'Information Security and Intellectual Property');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategoriescodes`
--

CREATE TABLE IF NOT EXISTS `tblcategoriescodes` (
  `categoryCodeIndex` int(11) NOT NULL AUTO_INCREMENT,
  `categoryName` varchar(128) NOT NULL,
  `categoryCode` varchar(128) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`categoryCodeIndex`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tblcategoriescodes`
--

INSERT INTO `tblcategoriescodes` (`categoryCodeIndex`, `categoryName`, `categoryCode`) VALUES
(1, 'Labor/Employment Law', 'Labor/Employment Law'),
(2, 'Antitrust and Fair Competition', 'Antitrust and Fair Competition'),
(3, 'Business Conduct and Ethics', 'Business Conduct and Ethics'),
(4, 'Finance and Accounting', 'Finance and Accounting'),
(5, 'Information Security and Intellectual Property', 'Information Security and Intellectual Property'),
(6, 'International Trade', 'International Trade'),
(7, 'Government Contracting', 'Government Contracting'),
(8, 'European Courses (Courses suitable for European audience with little or no customization required)', 'European Courses'),
(9, 'Global Courses (Courses suitable for global audience with little or no customization required)\nCATEGORY AREAS\n', 'Global Courses'),
(10, 'Focus Courses\r\n', 'Focus Courses'),
(11, 'Consumer Protection', 'Consumer Protection'),
(12, 'EthiFlicks™', 'EthiFlick'),
(13, 'RealBiz Shorts: Energy', 'RealBiz Shorts'),
(14, 'True Office Solutions Courses', 'True Office Solutions Courses'),
(15, 'Modular Code Courses (Modular versions are not to be deployed together with Foundation versions)', 'Modular Code Courses'),
(16, 'RealBiz Shorts: Life Sciences', 'RealBiz Shorts: Life Sciences'),
(17, 'RealBiz Shorts: Ethics & Compliance', 'RealBiz Shorts: Ethics & Compliance');

-- --------------------------------------------------------

--
-- Table structure for table `tblcoursecatalog`
--

CREATE TABLE IF NOT EXISTS `tblcoursecatalog` (
  `courseName` varchar(128) CHARACTER SET utf8 NOT NULL,
  `courseNumber` varchar(30) CHARACTER SET utf8 NOT NULL,
  `length` varchar(30) CHARACTER SET utf8 NOT NULL,
  `daysFromHire` varchar(30) CHARACTER SET utf8 NOT NULL,
  `trainingFreq` varchar(30) CHARACTER SET utf8 NOT NULL,
  `recAudience` varchar(128) CHARACTER SET utf8 NOT NULL,
  `courseDesc` longtext CHARACTER SET utf8 NOT NULL,
  `courseStatus` varchar(128) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`courseNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcoursecatalog`
--

INSERT INTO `tblcoursecatalog` (`courseName`, `courseNumber`, `length`, `daysFromHire`, `trainingFreq`, `recAudience`, `courseDesc`, `courseStatus`) VALUES
('Preventing Money Laundering: EU Insurers Without US Dealings', '45305', 'asdf', 'asdf', 'asdf', 'asdf', 'Preventing Money Laundering (EU Insurers without US\nDealings)” addresses the risk posed to your organization\nby criminals determined to launder dirty money through\ninsurance products and services. Money laundering\npresents a real risk to insurance entities because of the\nlarge number of investment vehicles that can be used to\nfurther financial crime. Moreover, money launderers may\ntarget your organization because your good name can lend\na sense of legitimacy to your actions. This course provides\na clear overview of EU anti-money laundering directives,\nregulations, and laws; describes how money launderers\noperate; details effective know-your-customer practices\n\nthat are required by government regulators and can help to\nprevent money laundering activity; and explains what to do\nif money laundering is suspected. Scenarios and activities\nare used throughout the course to illustrate appropriate\nbehavior in given situations and to help ensure learner\nunderstanding.', 'Active'),
('Encouraging Workplace Diversity', '45370', '30 minutes', '90', '2 years', 'tesasdf', 'asdfasdf asdfdads asdfads asdf\n\nasdfasd\n\nasdf', 'Active'),
('Encouraging Reporting and Conducting Investigations: US Edition test', '45383', '10 min', '90', '2 years', 'RECOMMENDED AUDIENCE This course is designed for all supervisors who handle or investigate whistleblower reports', 'tes', 'Active'),
('Preventing Employment Discrimination: Global Edition', '45388', '30 minutes', '90', '2 years', 'This course is designed for all managers in the workplace', 'test', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tblkeywords`
--

CREATE TABLE IF NOT EXISTS `tblkeywords` (
  `keywordIndex` int(11) NOT NULL AUTO_INCREMENT,
  `keywords` varchar(450) CHARACTER SET utf8 NOT NULL,
  `courseNumber` int(30) NOT NULL,
  PRIMARY KEY (`keywordIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbllanguagecodes`
--

CREATE TABLE IF NOT EXISTS `tbllanguagecodes` (
  `languageCodeIndex` int(11) NOT NULL AUTO_INCREMENT,
  `languageCode` varchar(128) CHARACTER SET utf8 NOT NULL,
  `languageText` varchar(128) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`languageCodeIndex`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `tbllanguagecodes`
--

INSERT INTO `tbllanguagecodes` (`languageCodeIndex`, `languageCode`, `languageText`) VALUES
(1, 'en', 'English'),
(2, 'ar', 'Arabic'),
(3, 'hy', 'Armenian'),
(4, 'zh_Hant', 'Chinese(Traditional)'),
(5, 'hr', 'Croatian'),
(6, 'cs', 'Czech'),
(7, 'da', 'Danish'),
(8, 'nl', 'Dutch'),
(9, 'en_CA', 'English(Canadian)'),
(10, 'en_GB', 'English(UnitedKingdom)'),
(11, 'et', 'Estoniankeel'),
(12, 'tl', 'Filipino'),
(13, 'fi', 'Finnish'),
(14, 'fl', 'Flemish'),
(15, 'fr', 'French'),
(16, 'fr_BE', 'French(Belgium)deBelgique'),
(17, 'fr_CA', 'French(Canadian)canadien'),
(18, 'ka', 'Georgian?'),
(19, 'de', 'German'),
(20, 'el', 'Greek'),
(21, 'he', 'Hebrew'),
(22, 'hi', 'Hindi?'),
(23, 'hu', 'Hungarian'),
(24, 'id', 'Indonesian'),
(25, 'is', 'Icelandic'),
(26, 'it', 'Italian'),
(27, 'ja', 'Japanese'),
(28, 'ko', 'Korean'),
(29, 'lv', 'Latvian'),
(30, 'lt', 'Lithuanian'),
(31, 'ms', 'Malay'),
(32, 'ml', 'Malayalam?'),
(33, 'no', 'Norwegian'),
(34, 'pl', 'Polish'),
(35, 'pt', 'Portuguese'),
(36, 'pt_BR', 'Portuguese(Brazil)doBrasil'),
(37, 'ro', 'Romanian'),
(38, 'ru', 'Russian'),
(39, 'sr', 'Serbian'),
(40, 'si', 'Sinhala?'),
(41, 'sk', 'Slovak'),
(42, 'es', 'Spanish(Castilian)'),
(43, 'es_AR', 'Spanish(Argentina) para Argentina'),
(44, 'es_CL', 'Spanish(Chile)para Chile'),
(45, 'es_419', 'Spanish(LatinAmerican)'),
(46, 'sv', 'Swedish'),
(47, 'ta', 'Tamil?'),
(48, 'th', 'Thai'),
(49, 'tr', 'Turkish'),
(50, 'uk', 'Ukrainian'),
(51, 'ur', 'Urdu'),
(52, 'vi', 'Vietnamese');

-- --------------------------------------------------------

--
-- Table structure for table `tbllanguages`
--

CREATE TABLE IF NOT EXISTS `tbllanguages` (
  `Index` int(11) NOT NULL AUTO_INCREMENT,
  `languageIndex` varchar(128) CHARACTER SET utf8 NOT NULL,
  `courseNumber` int(30) NOT NULL,
  `languageCode` varchar(128) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`Index`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1135 ;

--
-- Dumping data for table `tbllanguages`
--

INSERT INTO `tbllanguages` (`Index`, `languageIndex`, `courseNumber`, `languageCode`) VALUES
(379, 'lang1', 45383, 'sv'),
(380, 'lang2', 45383, 'lt'),
(381, 'lang3', 45383, 'ur'),
(383, 'lang4', 45383, 'es_419'),
(384, 'lang1', 45370, 'sv'),
(385, 'lang2', 45370, 'es_419'),
(387, 'lang3', 45370, 'ar'),
(389, 'lang4', 45370, 'ur'),
(507, 'lang1', 45388, 'en'),
(779, 'lang2', 45388, 'ar'),
(780, 'lang3', 45388, 'sv'),
(781, 'lang4', 45388, 'ar'),
(1133, 'lang0', 45305, 'en'),
(1134, 'lang1', 45305, 'zh_Hans');

-- --------------------------------------------------------

--
-- Table structure for table `tbltopicscovered`
--

CREATE TABLE IF NOT EXISTS `tbltopicscovered` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `courseNumber` int(30) NOT NULL,
  `topicIndex` varchar(11) CHARACTER SET utf8 NOT NULL,
  `topicDesc` varchar(450) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1516 ;

--
-- Dumping data for table `tbltopicscovered`
--

INSERT INTO `tbltopicscovered` (`index`, `courseNumber`, `topicIndex`, `topicDesc`) VALUES
(265, 45383, 'topic1', 'Identify best practices for encouraging employee reporting'),
(266, 45383, 'topic2', 'Identify best practices for encouraging employee repo'),
(267, 45383, 'topic3', 'Describe how to handle allegations of the'),
(268, 45383, 'topic4', 'Explain how to conduct investigations thoroughly and fairly'),
(269, 45383, 'topic5', 'Handle inconclusive or illegitimate reports'),
(292, 45370, 'topic1', 'Explain the role diversity plays in business'),
(293, 45370, 'topic2', 'Describe how to be respectful and supportive of a diverse enviorment'),
(294, 45370, 'topic3', 'Demonstrate how to overcome disrespectful attitudes and respond to inappropriate conduct'),
(581, 45388, 'topic1', 'Identify and prevent discrimination at the workplace'),
(582, 45388, 'topic2', 'Describe the importance of discrimination policies'),
(583, 45388, 'topic3', 'Demonstrate best practices to ensure fair employment practices'),
(584, 45388, 'topic4', 'Report any actual or potential discrimination they are aware of'),
(1512, 45305, 'topic1', 'Explain what laws and regulators combat money laundering'),
(1513, 45305, 'topic2', 'Describe how money launderers operate and identify suspicious activities'),
(1514, 45305, 'topic3', 'Demonstrate effective know-your-customer practices to help prevent money laundering'),
(1515, 45305, 'topic4', 'Explain what to do if you suspect money laundering activities');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
