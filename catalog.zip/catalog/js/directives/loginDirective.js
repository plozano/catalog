'use strict';
myApp.directive('loginDirective', function () {
	return{
		templateUrl: 'views/tpl/login.tpl.html',
	}

})